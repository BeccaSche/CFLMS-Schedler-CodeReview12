  
	</main>
	<footer>
		<div class="footer d-flex justify-content-between px-5 py-4">
			<div>Mount Everest Travel</div>
			<div>Rebecca Schedler - CodeFactory Vienna</div>
		</div>
	</footer>

   <?php wp_footer(); ?>

</body>
</html>